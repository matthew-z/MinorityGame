# !/usr/bin/env python3
# coding: utf-8
from minority_game import MinorityGameWithStrategyTable

if __name__ == '__main__':
    game = MinorityGameWithStrategyTable(201, 50000, 3, 2, 64)
    game.run_game()
    print(game.winner_for_diff_group())
